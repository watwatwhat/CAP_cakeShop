sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("cakeshopapp.cakeshopapp.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map